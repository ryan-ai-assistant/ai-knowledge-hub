---
title: Framework – Internal Response
tags: [frameworks/internal-response, communication/internal/slack, communication/internal/email]
version: 1.0
owner: ryan.brock
---
## Purpose
Provide crisp, aligned internal responses that unblock decision-making.

## Steps
1. Restate the ask.
2. Provide the answer or options with tradeoffs.
3. Identify owners and next steps.
4. Link to related docs or resources.

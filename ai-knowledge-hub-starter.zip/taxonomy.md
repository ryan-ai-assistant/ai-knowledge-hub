# Tag Taxonomy (Seed)

Use multi-layer tags to improve retrieval. Examples included here are initial seeds.

- strategy/district
- communication/district
- communication/internal/slack
- communication/internal/email
- analytics/internal
- analytics/external
- education/math
- education/ela
- templates/meeting-summary
- templates/reminder-email
- templates/session-recap
- frameworks/implementation-success
- frameworks/project-plan
- frameworks/partner-response
- frameworks/internal-response
- frameworks/digesting-information
- frameworks/create-from-knowledge
- tone/professional
- tone/lisa-damour
- structure/meeting-recap
- style/no-extras

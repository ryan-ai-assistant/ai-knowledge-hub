---
title: Template – Slack: Resources
tags: [communication/internal/slack, templates/slack, style/no-extras, tone/professional]
version: 1.0
owner: ryan.brock
inputs:
  - { name: resources, type: list, required: true }
---
Resources

- {resources}

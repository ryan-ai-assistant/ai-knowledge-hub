---
title: Template – Slack: Action Steps
tags: [communication/internal/slack, templates/slack, style/no-extras, tone/professional]
version: 1.0
owner: ryan.brock
inputs:
  - { name: project_name, type: string, required: true }
  - { name: actions, type: list, required: true }
---
{project_name} — Action Steps

- [ ] {actions}

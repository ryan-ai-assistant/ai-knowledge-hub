---
title: Style – No Extras
tags: [module, style/no-extras]
---
Do not use emojis.
Do not use em dashes; use commas or semicolons if needed.
Avoid overused AI phrases (e.g., "as an AI", "delve", "leverage synergies", "cutting-edge").
Avoid filler and marketing clichés.
Prefer short sentences. Prefer concrete nouns and verbs.

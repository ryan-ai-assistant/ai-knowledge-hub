---
title: Structure – Meeting Recap
tags: [module, structure/meeting-recap]
---
Use the following sections in order:
- Context
- Attendees (with roles)
- Objectives
- Key Points
- Decisions
- Risks / Open Questions
- Action Items (owner, due date)
- Next Steps

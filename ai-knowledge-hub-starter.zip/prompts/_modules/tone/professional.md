---
title: Tone – Professional
tags: [module, tone/professional]
---
Write with clarity and concision. Use direct sentences. Avoid emojis. Avoid em dashes. Avoid filler and hype words.
Use active voice. Be respectful and neutral. Provide actionable guidance.

## Request Type
- [ ] New prompt
- [ ] Improve prompt
- [ ] New template
- [ ] New framework

## Details
- Purpose:
- Audience:
- Tags (comma-separated):
- Inputs (placeholders):
- Related items:

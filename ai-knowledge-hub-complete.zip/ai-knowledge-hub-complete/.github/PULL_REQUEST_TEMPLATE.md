### Summary
Describe what's being added or changed.

### Checklist
- [ ] YAML front-matter present (title, tags, owner)
- [ ] Tags align with taxonomy
- [ ] Modules referenced correctly
- [ ] No sensitive info

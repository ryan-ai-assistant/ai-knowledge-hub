---
title: Template – Slack: Reminders
tags: [communication/internal/slack, templates/slack, style/no-extras, tone/human]
version: 1.0
owner: ryan.brock
inputs:
  - { name: reminders, type: list, required: true }
---
Reminders

- {reminders}

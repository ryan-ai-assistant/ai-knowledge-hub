---
title: Framework – Project Plan (Event/Series)
tags: [frameworks/project-plan, strategy/district, productivity]
version: 1.0
owner: ryan.brock
---
## Stages
1. Objectives & Success Criteria
2. Stakeholders & Roles
3. Timeline & Milestones
4. Communications & Promotion
5. Logistics & Risk Management
6. Delivery & Follow-up

---
title: Framework – Partner Response (External)
tags: [frameworks/partner-response, communication/district]
version: 1.0
owner: ryan.brock
---
## Steps
1. Clarify the question and context.
2. Cite authoritative guidance.
3. Provide a direct answer with rationale.
4. Add examples or steps.
5. Offer support/resources.

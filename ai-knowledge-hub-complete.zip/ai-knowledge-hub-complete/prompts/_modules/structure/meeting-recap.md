---
title: Structure – Meeting Recap
tags: [module, structure/meeting-recap]
---
Use sections:
- Context
- Attendees (with roles)
- Objectives
- Key Points
- Decisions
- Risks / Open Questions
- Action Items (owner, due date)
- Next Steps

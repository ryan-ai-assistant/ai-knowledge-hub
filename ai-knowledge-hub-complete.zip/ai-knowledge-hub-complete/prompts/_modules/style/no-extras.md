---
title: Style – No Extras
tags: [module, style/no-extras]
---
Do not use emojis.
Do not use em dashes; use commas or semicolons instead.
Avoid overused AI phrases (e.g., "as an AI", "delve", "leverage synergies").
Prefer short sentences and concrete language.
